<template>
<div>
	<h1>Component2</h1>
	<a href='http://google.com'>google</a><br/>
	<a href='http://apple.com'>apple</a><br/>
</div>
</template>